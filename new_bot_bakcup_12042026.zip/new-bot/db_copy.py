import mysql.connector
from mysql.connector import Error
from collections import OrderedDict
from collections import defaultdict
from datetime import datetime, timedelta

def connect_to_database_windows():
    try:
        connection = mysql.connector.connect(
            host="192.168.1.63",
            user="telegram",
            password="wmc[rwT9GECwk-O[",
            database="absensi"
        )
        return connection
    except Error as err:
        print(f"Error: {err}")
        return None
    
    
#Displays all employees by division and job title
def input_absensi_to_windows(pin,date):
    query = f"""
    INSERT INTO `att_log` 
    (`sn`, `scan_date`, `pin`, `verifymode`, `inoutmode`, `reserved`, `work_code`, `att_id`) VALUES 
    ('999', '{date}', '{pin}', '100', '10', '0', '0', '')"""
    
    try:
        connection = connect_to_database_windows()
        if connection:
            cursor = connection.cursor()
            cursor.execute(query)
            connection.commit()
            return True

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return str(err) 

    finally:
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()


input_absensi_to_windows(840119,'2026-04-13 08:45:14')